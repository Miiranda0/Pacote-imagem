from .processamento import redimensionar_imagem
